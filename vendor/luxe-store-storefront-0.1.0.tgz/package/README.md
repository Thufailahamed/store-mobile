# `@luxe/store-storefront`

Shared storefront renderer + schema + registry consumed by:

- `store/` (web / Next.js — via npm workspace)
- `store-mobile/` (Expo RN — via `git+path` from this repo)

## Editing

Edit files here in `packages/store-storefront/src/`. Both apps pick up changes on next install/build.

## Versioning for mobile

Mobile pins via `git ref=...` in its `package.json`. When you change schema in a breaking way, tag this repo:

```bash
git tag storefront-v0.2.0
git push --tags
```

Then update `store-mobile/package.json`:
```json
"@luxe/store-storefront": "git+https://github.com/<org>/store.git#path=packages/store-storefront&ref=storefront-v0.2.0"
```

For non-breaking changes, leave `ref=main` and just `npm install` in mobile to pull.

## Deploy

This package has no deploy target. It is bundled into web (Vercel) and mobile (EAS) builds.